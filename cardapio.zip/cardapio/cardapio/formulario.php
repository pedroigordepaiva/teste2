<!DOCTYPE html>
<html>
    <head>
        <!--Aqui se coloca estruturas que não aparecem diretamente dentro do site.-->
        <title>Página principal</title>
        <meta charset="utf8">
   
        <link rel="stylesheet" type="text/css"  href="estilo.css">
   
        <style  type="text/css">
            #nome, #email{
                width: 450px;
                height: 20px;
            }
            textarea {
                font: 1em sans-serif;
                width: 460px;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
                height: 5em;
                vertical-align: top;
                resize: vertical;
                border: 1px solid #999;
            }   
            
        </style>
        

    </head>

    <body>

        <div id="principal">

            <div id="menu"> <!--inicio do conteudo-->
                <a href="index.php">HOME</a> |
                <a href="formulario.php">NOS AVALIE</a> |
                <a href="index.php">QUEM SOMOS</a>|
                <a href="relatorio.php">RELATÓRIO</a>

            </div> <!--fim do menu-->

          
    </div>    
    
        <form method="post" action="enviar.php">

            <h2>Avalie nosso Restaurante</h2>

            <div>
                <label>Nome:</label>
                <input type="text" id="nome" name="nome" />
            </div>
            <div>
                <label for="email">E-mail:</label>
                <input type="email" id="email" name="email"/>
            </div>
            <div>
                <label for="msg">Avaliação:</label>
                <textarea id="avaliacao" name="avaliacao"></textarea>
            </div>
            <div class="button">
                <button type="submit">Enviar</button>
            </div>

        </form>

    </body>


</html>