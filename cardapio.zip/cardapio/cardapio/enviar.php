<?php

include_once "conexao.php";



$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$avaliacao = filter_input(INPUT_POST, 'avaliacao', FILTER_SANITIZE_STRING);


$result_avaliacao = "INSERT INTO avaliacao (DSC_NOME, DSC_EMAIL, DSC_AVALIACAO, DAT_AVALIACAO) VALUES ('$nome', '$email', '$avaliacao', NOW())";
$result = mysqli_query($conn, $result_avaliacao);

?>


<html>
<head>
        <!--Aqui se coloca estruturas que não aparecem diretamente dentro do site.-->
        <title>Relatório de Avaliações</title>
        <meta charset="utf8">
        
    
       <style  type="text/css">
            body{
               background: #d2d2c1;
            }
           
            #menu{
                padding: 18px;
                margin: 20px 750px;
                width: 900px;
            }
            
            .img{
                padding: 18px;
                margin: 20px 500px;
                
            }

        </style>
       

    </head>
    <body>
        <div id="menu"> <!--inicio do conteudo-->
                <a href="index.php">HOME</a>
        </div> <!--fim do menu-->
        <img src="imagens/obrigadoParticipacao.png" class="img">

    </body>    
</html>    