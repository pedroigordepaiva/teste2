

<?php

include_once "conexao.php";

$vSql = "SELECT DSC_NOME, DSC_EMAIL, DSC_AVALIACAO, DATE_FORMAT(DAT_AVALIACAO,'%d/%m/%Y %Hh%i') AS DAT_AVALIACAO FROM cardapio.avaliacao";

?>

<html>
    <head>
        <!--Aqui se coloca estruturas que não aparecem diretamente dentro do site.-->
        <title>Relatório de Avaliações</title>
        <meta charset="utf8">

       <style  type="text/css">
            body{
               background: #d2d2c1;
            }
            .titulo{
                font-size: 40px;
                text-align: center;
            }
            th {
                font-size: 18px;
                padding: 8px;
                background: #d1d19d;
            }
            td {
                font-size: 18px;
                padding: 8px;
                text-align: left;
            }
            #menu{
                padding: 18px;
                margin: 20px 600px;
                width: 900px;
            }
            a {
                color: #4b566a;
                text-decoration: none;
                font-weight: bold;
                padding: 5px;
            }
            
        </style>
       

    </head>

    <body>        

            <div id="menu"> <!--inicio do conteudo-->
                <a href="index.php">HOME</a> |
                <a href="formulario.php">NOS AVALIE</a> |
                <a href="index.php">QUEM SOMOS</a> |
                <a href="relatorio.php">RELATÓRIO</a> 

            </div> <!--fim do menu-->

        <h3 class="titulo">Relatório de Avaliação</h3>
        <table border="1" width="80%" align="center">
            <tr>
                <th width="180px">Nome</th>
                <th width="150px">E-mail</th>
                <th>Avaliação</th>
                <th width="180px"> Data da Avaliação</th>
            </tr>
            
<?php
$arResult = mysqli_query($conn, $vSql);


while ($tbl = mysqli_fetch_array($arResult)) {
    $nome =  $tbl['DSC_NOME'];
    $email =  $tbl['DSC_EMAIL'];
    $dscAvaliacao =  $tbl['DSC_AVALIACAO'];
    $datAvaliacao =  $tbl['DAT_AVALIACAO'];
    
    
    echo "<tr>";
    echo "<td>$nome</td>";         
    echo "<td>$email</td>";
    echo "<td>$dscAvaliacao</td>";
    echo "<td>$datAvaliacao</td>";
    echo "</tr>";
}
?>

</table>
</body>
</html>
