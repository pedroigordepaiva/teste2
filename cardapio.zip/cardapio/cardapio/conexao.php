<?php
$servidor="localhost";
$usuario="root";
$senha="";
$dbname="cardapio";

$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);