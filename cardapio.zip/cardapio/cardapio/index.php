<!DOCTYPE html>
<html>
    <head>
        <!--Aqui se coloca estruturas que não aparecem diretamente dentro do site.-->
        <title>Página principal</title>
        <meta charset="utf8">

         <link rel="stylesheet" type="text/css"  href="estilo.css">
   
    </head>

    
    <body>
        <div id="principal">

            <div id="menu"> <!--inicio do conteudo-->
                <a href="index.php">HOME</a> |
                <a href="formulario.php">NOS AVALIE</a> |
                <a href="index.php">QUEM SOMOS</a> |
                <a href="relatorio.php">RELATÓRIO</a>

            </div> <!--fim do menu-->

            <img src="imagens/cardapio-lanchonete-1.png" class="img-campanha">
    </div>    
        

       
            

        

    </body>

</html>